```bash
make
```
