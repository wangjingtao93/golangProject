rbac-external-provisioner.yaml was copied from https://github.com/kubernetes-csi/external-provisioner/blob/master/deploy/kubernetes/rbac.yaml
and must be refreshed when updating the external-provisioner image in setup-csi-snapshotter.yaml
